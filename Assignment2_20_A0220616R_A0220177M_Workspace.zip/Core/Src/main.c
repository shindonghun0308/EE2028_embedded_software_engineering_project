#include "main.h"

// =============================================================================
UART_HandleTypeDef huart1;
VL53L0X_Dev_t sensor1;  // time of flight ranging sensor

// Sensor monitoring
XYZData accel_data;
XYZData gyro_data;
XYZData magneto_data;
float temp_data;
float pressure_data;
float humidity_data;

char accel_message[256];
char gyro_message[256];
char magneto_message[256];
char temp_message[256];
char pressure_message[256];
char humidity_message[256];

char all_message[2048];

// Tick counting
uint32_t endTickMSG = 0;
uint32_t led1Tick = 0;
uint32_t led2Tick = 0;
char tick_message[64];

// Mode changing
// E for Exploration
// B for Battle
// W for Warning
// O for Overload
char mode = 'E';
char prev_mode = 'E';

int pressCount = 0;
int pressDuration = 0;

// Threshold in order:
// - Gyroscope
// - Magnetometer
// - Pressure Sensor
// - Humidity Sensor
// - Accelerometer
// - Temperature
int thresholdArr[6] = {0, 0, 0, 0, 0, 0};

// Battle mode info
int batteryLevel = 8;
uint32_t batteryTick = 0;
char battery_message[256];

// Overload mode
uint32_t overloadTick = 0;
int enemyDead = 1;
int firingAltitude = 0;
int enemyPosition;

char overload_message[256];

// =============================================================================
// Listen to external interrupt from pin
HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
  if (GPIO_Pin == BUTTON_EXTI13_Pin &&
      HAL_GetTick() - pressDuration > DEBOUNCE_DELAY) {
    // Eliminate debouncing from the button
    pressCount += 1;
    if (pressDuration == 0) {
      // Start recording the time of the first press
      pressDuration = HAL_GetTick();
    }
  }
}

// =============================================================================
int main(void) {
  /* Reset of all peripherals, Initializes Systick etc. */
  HAL_Init();

  /* UART initialization  */
  UART1_Init();

  /* Peripheral initializations using BSP functions */
  BSP_ACCELERO_Init();
  BSP_GYRO_Init();
  BSP_MAGNETO_Init();
  BSP_TSENSOR_Init();
  BSP_PSENSOR_Init();
  BSP_HSENSOR_Init();

  /* Self configure peripheral */
  MX_GPIO_Init();
  VL53L0X_Start(&sensor1);

  // Send Exploration message once on boot up
  HAL_UART_Transmit(&huart1, (uint8_t *)EXPLORATION_MSG,
                    strlen(EXPLORATION_MSG), 0xFFFF);

  while (1) {
    checkPress();

    if (mode == 'E') {
      enterExplorationMode();
    }

    if (mode == 'B') {
      enterBattleMode();
    }

    if (mode == 'W') {
      enterWarningMode(prev_mode);
    }

    if (mode == 'O') {
      enterOverloadMode();
    }
  }
}

// =============================================================================
/**
 * @brief Contain the logic for single press and double press in different
 * mode
 * @retval void
 */
void checkPress(void) {
  if (HAL_GetTick() - pressDuration <= ONE_SECOND && pressCount >= 2) {
    // reset the count and duration
    pressCount = 0;
    pressDuration = 0;
    HAL_UART_Transmit(&huart1, (uint8_t *)"Double Pressed\r\n",
                      strlen("Double Pressed\r\n"), 0xFFFF);

    // Switching mode logic
    if (mode == 'E') {
      mode = 'B';
      // Reset all the tick
      led1Tick = HAL_GetTick();
      led2Tick = HAL_GetTick();
      batteryTick = HAL_GetTick();
      endTickMSG = HAL_GetTick();
      HAL_UART_Transmit(&huart1, (uint8_t *)BATTLE_MSG, strlen(BATTLE_MSG),
                        0xFFFF);
      enterBattleMode();
    } else if (mode == 'B') {
      mode = 'E';
      // Reset all the tick
      led1Tick = HAL_GetTick();
      led2Tick = HAL_GetTick();
      endTickMSG = HAL_GetTick();
      enterExplorationMode();
    }

  } else if (HAL_GetTick() - pressDuration > ONE_SECOND && pressCount == 1) {
    // reset the count and duration
    pressCount = 0;
    pressDuration = 0;
    HAL_UART_Transmit(&huart1, (uint8_t *)"Single Pressed\r\n",
                      strlen("Single Pressed\r\n"), 0xFFFF);

    // If battle mode and without max battery
    // Increase batterly level
    if (mode == 'B' && batteryLevel < MAX_BATTERY) {
      batteryLevel += 1;
    }

    // If battle mode and with max battery level
    // Change to OVERLOAD mode
    if (mode == 'B' && batteryLevel == MAX_BATTERY) {
      mode = 'O';
      // Reset all the tick
      HAL_UART_Transmit(&huart1, (uint8_t *)OVERLOAD_MSG, strlen(OVERLOAD_MSG),
                        0xFFFF);
      enterOverloadMode();
    }

    // If warning mode
    // Clear all the threshold
    // and change back to the previous mode that it was in
    if (mode == 'W') {
      thresholdArr[0] = 0;
      thresholdArr[1] = 0;
      thresholdArr[2] = 0;
      thresholdArr[3] = 0;
      thresholdArr[4] = 0;
      thresholdArr[5] = 0;

      HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);

      if (prev_mode == 'E') {
        mode = 'E';
        led1Tick = HAL_GetTick();
        led2Tick = HAL_GetTick();
        endTickMSG = HAL_GetTick();
        enterExplorationMode();
      } else {
        mode = 'B';
        led1Tick = HAL_GetTick();
        led2Tick = HAL_GetTick();
        batteryTick = HAL_GetTick();
        endTickMSG = HAL_GetTick();
        enterBattleMode();
      }
    }
  }
}

// =============================================================================
void enterExplorationMode(void) {
  prev_mode = 'E';

  // LED 1 is always on
  HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);

  // Logic to run every 1 second
  if (HAL_GetTick() - endTickMSG >= ONE_SECOND) {
    sprintf(tick_message, "Elapsed: %i ms\r\n",
            (int)(HAL_GetTick() - endTickMSG));
    HAL_UART_Transmit(&huart1, (uint8_t *)tick_message, strlen(tick_message),
                      0xFFFF);

    // Get all the necessary data
    gyro_data = getGyroData();
    magneto_data = getMagnetoData();
    pressure_data = getPressureData();
    humidity_data = getHumidityData();

    if (gyro_data.z > GYRO_THRESHOLD) {
      thresholdArr[0] = 1;
    }

    if (magneto_data.z < MAGNETO_THRESHOLD) {
      thresholdArr[1] = 1;
    }

    if (pressure_data > PRESSURE_THRESHOLD) {
      thresholdArr[2] = 1;
    }

    if (humidity_data > HUMIDITY_THRESHOLD) {
      thresholdArr[3] = 1;
    }

    int sum = 0;
    for (int i = 0; i < 4; i++) {
      sum += thresholdArr[i];
    }
    if (sum >= 2) {
      mode = 'W';
      enterWarningMode(prev_mode);
    }

    sprintf(gyro_message, "Gyro Z: %f dps\r\n", gyro_data.z);
    sprintf(magneto_message, "Magneto Z: %f gauss\r\n", magneto_data.z);
    sprintf(pressure_message, "Pressure: %f hPa\r\n", pressure_data);
    sprintf(humidity_message, "Humidity: %f %%\r\n", humidity_data);
    sprintf(all_message, "%s%s%s%s\r\n", gyro_message, magneto_message,
            pressure_message, humidity_message);

    HAL_UART_Transmit(&huart1, (uint8_t *)all_message, strlen(all_message),
                      0xFFFF);
    endTickMSG = HAL_GetTick();
  }
}

// =============================================================================
void enterBattleMode(void) {
  prev_mode = 'B';

  // Blink at 1Hz rate
  blinkLED1(BATTLE_LED_DELAY);

  // Fire Fluxer every 5 second
  fireFluxer();

  // Logic to run every 1 second
  if (HAL_GetTick() - endTickMSG >= ONE_SECOND) {
    sprintf(tick_message, "Elapsed: %i ms\r\n",
            (int)(HAL_GetTick() - endTickMSG));
    HAL_UART_Transmit(&huart1, (uint8_t *)tick_message, strlen(tick_message),
                      0xFFFF);

    sprintf(battery_message, "Battery: %i/10 energy\r\n", batteryLevel);
    HAL_UART_Transmit(&huart1, (uint8_t *)battery_message,
                      strlen(battery_message), 0xFFFF);

    // Get all the necessary data
    accel_data = getAccelerometerData();
    gyro_data = getGyroData();
    magneto_data = getMagnetoData();
    temp_data = getTemperatureData();
    pressure_data = getPressureData();
    humidity_data = getHumidityData();

    if (gyro_data.z > GYRO_THRESHOLD) {
      thresholdArr[0] = 1;
    }

    if (magneto_data.z < MAGNETO_THRESHOLD) {
      thresholdArr[1] = 1;
    }

    if (pressure_data > PRESSURE_THRESHOLD) {
      thresholdArr[2] = 1;
    }

    if (humidity_data > HUMIDITY_THRESHOLD) {
      thresholdArr[3] = 1;
    }

    if (accel_data.z > ACCEL_THRESHOLD) {
      thresholdArr[4] = 1;
    }

    if (temp_data > TEMP_THRESHOLD) {
      thresholdArr[5] = 1;
    }

    int sum = 0;
    for (int i = 0; i < 6; i++) {
      sum += thresholdArr[i];
    }
    if (sum >= 1) {
      mode = 'W';
      enterWarningMode(prev_mode);
    }

    sprintf(accel_message, "Accel Z : %f g\r\n", accel_data.z);
    sprintf(gyro_message, "Gyro Z: %f dps\r\n", gyro_data.z);
    sprintf(magneto_message, "Magneto Z: %f gauss\r\n", magneto_data.z);
    sprintf(temp_message, "Temperature: %f °C\r\n", temp_data);
    sprintf(pressure_message, "Pressure: %f hPa\r\n", pressure_data);
    sprintf(humidity_message, "Humidity: %f %%\r\n", humidity_data);

    sprintf(all_message, "%s%s%s%s%s%s\r\n", accel_message, gyro_message,
            magneto_message, temp_message, pressure_message, humidity_message);

    HAL_UART_Transmit(&huart1, (uint8_t *)all_message, strlen(all_message),
                      0xFFFF);
    endTickMSG = HAL_GetTick();
  }
}
// =============================================================================
void blinkLED1(int delay) {
  if (HAL_GetTick() - led1Tick >= delay) {
    led1Tick = HAL_GetTick();
    HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
  }
}

// =============================================================================
void fireFluxer(void) {
  if (batteryLevel >= 2 && HAL_GetTick() - batteryTick >= FLUXER_DELAY) {
    batteryTick = HAL_GetTick();
    batteryLevel -= 2;
    HAL_UART_Transmit(&huart1, (uint8_t *)FLUXER_MSG, strlen(FLUXER_MSG),
                      0xFFFF);
  }
}

// =============================================================================
void enterWarningMode(char prev_mode) {
  if (prev_mode == 'E') {
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
  } else {
    blinkLED1(BATTLE_LED_DELAY);
  }

  blinkLED2(WARNING_LED_DELAY);

  if (HAL_GetTick() - endTickMSG >= 1000) {
    sprintf(tick_message, "Elapsed: %i ms\r\n",
            (int)(HAL_GetTick() - endTickMSG));
    HAL_UART_Transmit(&huart1, (uint8_t *)tick_message, strlen(tick_message),
                      0xFFFF);

    HAL_UART_Transmit(&huart1, (uint8_t *)WARNING_MSG, strlen(WARNING_MSG),
                      0xFFFF);

    endTickMSG = HAL_GetTick();
  }
}

// =============================================================================
void blinkLED2(int delay) {
  if (HAL_GetTick() - led2Tick >= delay) {
    led2Tick = HAL_GetTick();
    HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
  }
}

// =============================================================================
void enterOverloadMode(void) {
  // Turn of LED 1, Turn on LED 2
  HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);

  if (enemyDead == 1) {
    // if enemy is Dead, spawn a new enemy
    enemyDead = 0;
    // generate a random position for enemy
    enemyPosition = rand() % 2;
    if (enemyPosition == 0) {
      HAL_UART_Transmit(&huart1, (uint8_t *)ENEMY_BELOW_MSG,
                        strlen(ENEMY_BELOW_MSG), 0xFFFF);
    } else {
      HAL_UART_Transmit(&huart1, (uint8_t *)ENEMY_ABOVE_MSG,
                        strlen(ENEMY_ABOVE_MSG), 0xFFFF);
    }
  } else {
    // if enemy is alive
    // start the aiming session, runs every 0.25s, mm is raw data
    if (HAL_GetTick() - overloadTick >= 250) {
      uint32_t distance;
      VL53L0X_GetDistance(&sensor1, &distance);

      // distance is first measured, and the prev; firingAltitude = prev
      // distance/10
      if (firingAltitude != 0 && distance == 0) {
        if (firingAltitude > 25 && enemyPosition == 1) {
          HAL_UART_Transmit(&huart1, (uint8_t *)ENEMY_HIT_MSG,
                            strlen(ENEMY_HIT_MSG), 0xFFFF);

          enemyDead = 1;  // kill the enemy

        } else if (firingAltitude <= 25 && enemyPosition == 0) {
          HAL_UART_Transmit(&huart1, (uint8_t *)ENEMY_HIT_MSG,
                            strlen(ENEMY_HIT_MSG), 0xFFFF);

          enemyDead = 1;  // kill the enemy
        } else {
          HAL_UART_Transmit(&huart1, (uint8_t *)ENEMY_MISSED_MSG,
                            strlen(ENEMY_MISSED_MSG), 0xFFFF);

          enemyDead = 1;
          mode = 'W';
          prev_mode = 'B';
          enterWarningMode(prev_mode);
        }
      }

      firingAltitude = distance / 10;

      if (firingAltitude > 0) {
        sprintf(overload_message, "Aiming altitude: %d cm\r\n", firingAltitude);
        HAL_UART_Transmit(&huart1, (uint8_t *)overload_message,
                          strlen(overload_message), 0xFFFF);
      }

      overloadTick = HAL_GetTick();
    }
  }
}

// =============================================================================
XYZData getAccelerometerData() {
  XYZData data;
  int16_t data_arr[3] = {0};
  BSP_ACCELERO_AccGetXYZ(data_arr);

  // raw data is in mg (g for gravity)
  data.x = (float)data_arr[0] / 1000.0f;
  data.y = (float)data_arr[1] / 1000.0f;
  data.z = (float)data_arr[2] / 1000.0f;
  return data;
}

// =============================================================================
XYZData getGyroData() {
  XYZData data;
  float data_arr[3] = {0};
  BSP_GYRO_GetXYZ(data_arr);

  // raw data is in mdps
  data.x = (float)data_arr[0] / 1000.0f;
  data.y = (float)data_arr[1] / 1000.0f;
  data.z = (float)data_arr[2] / 1000.0f;
  return data;
}

// =============================================================================
XYZData getMagnetoData() {
  XYZData data;
  int16_t data_arr[3] = {0};
  BSP_MAGNETO_GetXYZ(data_arr);

  // raw data is in mgauss/LSB
  data.x = (float)data_arr[0] / 1000.0f;
  data.y = (float)data_arr[1] / 1000.0f;
  data.z = (float)data_arr[2] / 1000.0f;
  return data;
}

// =============================================================================
float getTemperatureData() {
  float temp_data;
  temp_data = BSP_TSENSOR_ReadTemp();
  return temp_data;
}

// =============================================================================
float getPressureData() {
  float pressure_data;
  pressure_data = BSP_PSENSOR_ReadPressure();
  return pressure_data;
}

// =============================================================================
float getHumidityData() {
  float humidity_data;
  humidity_data = BSP_HSENSOR_ReadHumidity();
  return humidity_data;
}

// =============================================================================
static void MX_GPIO_Init(void) {
  __HAL_RCC_GPIOA_CLK_ENABLE();  // Enable AHB2 Bus for GPIOA
  __HAL_RCC_GPIOB_CLK_ENABLE();  // Enable AHB2 Bus for GPIOB
  __HAL_RCC_GPIOC_CLK_ENABLE();  // ENable AHB2 Bus for GPIOC
  __HAL_RCC_GPIOD_CLK_ENABLE();

  // Reset pin to 0
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  // Configuration of LED2_Pin (GPIO-B Pin-14) as GPIO output
  GPIO_InitStruct.Pin = LED2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Configuration of LED1_Pin (GPIO-A Pin-5) as GPIO output
  GPIO_InitStruct.Pin = LED1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  // Configuration of BUTTON_EXTI13_Pin (GPIO-C Pin-13)as AF
  GPIO_InitStruct.Pin = BUTTON_EXTI13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

// =============================================================================
static void UART1_Init(void) {
  /* Pin configuration for UART. BSP_COM_Init() can do this automatically */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
  GPIO_InitStruct.Pin = GPIO_PIN_7 | GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* Configuring UART1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK) {
    while (1)
      ;
  }
}

// =============================================================================
/**
 * @brief Initialize the VL53L0X sensor to work on the B-L475 board.
 * Originally created by JC-Toussaint on Github for Nucleo_L476RG board,
 * then adapted by LazyYuuki for B-L475 board
 * @retval void
 */
void VL53L0X_Start(VL53L0X_Dev_t *lidar) {
  lidar->I2cDevAddr = 0b0101001;  // ADDRESS_DEFAULT;
  lidar->comms_type = 1;          // VL53L0X_COMMS_I2C
  lidar->comms_speed_khz = 400;

  if (!VL53L0X_InitSensor(lidar, VL53L0x_DEFAULT_DEVICE_ADDRESS)) {
    char msg[256];
    sprintf(msg, "Failed to initialize\r\n");
    HAL_UART_Transmit(&huart1, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
  } else {
    char msg[256];
    sprintf(msg, "Successfully initialized\r\n");
    HAL_UART_Transmit(&huart1, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
  }
}

// =============================================================================
/**
 * @brief Extra Error Handler to debug the VL53L0X libraries
 * @retval void
 */
void _Error_Handler(char *file, int line) {
  /* USER CODE BEGIN Error_Handler_Debug */
  char msg[256];
  sprintf(msg, "%s,%d\r\n", file, line);
  /* User can add his own implementation to report the HAL error return state
   */
  while (1) {
    HAL_UART_Transmit(&huart1, (uint8_t *)msg, strlen(msg), 0xFFFF);
    HAL_Delay(1000);
  }
  /* USER CODE END Error_Handler_Debug */
}
